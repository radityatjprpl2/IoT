const int satu = 25;
const int dua = 33;
const int tiga = 32;

void setup() {
  pinMode(satu, OUTPUT);
  pinMode(dua, OUTPUT);
  pinMode(tiga, OUTPUT);
}

void loop() {
  digitalWrite(satu, HIGH);
  digitalWrite(dua, LOW);
  digitalWrite(tiga, LOW);
  delay(1000);

  digitalWrite(satu, LOW);
  digitalWrite(dua, HIGH);
  digitalWrite(tiga, LOW);
  delay(1000);

  digitalWrite(satu, LOW);
  digitalWrite(dua, LOW);
  digitalWrite(tiga, HIGH);
  delay(1000);

}